namespace RiwiMusic1.Models;

public class Consultas
{
    // Consultar conciertos por ciudad
    public static void conciertosPorCiudad()
    {
        Console.Write("Ingrese la ciudad: ");
        string ciudad = Console.ReadLine();

        var conciertos = Db.dbListas().Item2
            .Where(c => c.city == ciudad)
            .ToList();

        if (conciertos.Count == 0)
        {
            Console.WriteLine($"No hay conciertos en la ciudad {ciudad}");
        }
        else
        {
            foreach (var c in conciertos)
            {
                Console.WriteLine($"ID: {c.idConcert} -- {c.city} -- {c.date}");
            }
        }
        MenuConsults.menuConsults();
    }

    // Consultar conciertos por rango de fechas
    public static void conciertosPorRangoFechas()
    {
        Console.Write("Fecha inicial (ej: 01 de enero 2025): ");
        string fechaInicio = Console.ReadLine();
        Console.Write("Fecha final (ej: 31 de diciembre 2025): ");
        string fechaFin = Console.ReadLine();

        var conciertos = Db.dbListas().Item2
            .Where(c => String.Compare(c.date, fechaInicio) >= 0 && String.Compare(c.date, fechaFin) <= 0)
            .ToList();

        if (conciertos.Count == 0)
        {
            Console.WriteLine("No hay conciertos en el rango de fechas.");
        }
        else
        {
            foreach (var c in conciertos)
            {
                Console.WriteLine($"ID: {c.idConcert} -- {c.city} -- {c.date}");
            }
        }
        MenuConsults.menuConsults();
    }

    // Consultar el concierto con más tiquetes vendidos
    public static void conciertoMasTiquetesVendidos()
    {
        var tickets = Db.dbListas().Item4;
        if (tickets.Count == 0)
        {
            Console.WriteLine("No hay tiquetes registrados.");
            return;
        }

        var conciertoId = tickets
            .GroupBy(t => t.idConcert)
            .OrderByDescending(g => g.Count())
            .First().Key;

        var concierto = Db.dbListas().Item2.Find(c => c.idConcert == conciertoId);

        Console.WriteLine($"Concierto con más tiquetes vendidos: {concierto.city} ({concierto.date})");
        MenuConsults.menuConsults();
    }

    // Consultar ingresos totales de un concierto
    public static void ingresosPorConcierto()
    {
        Console.Write("Ingrese el ID del concierto: ");
        int id = int.Parse(Console.ReadLine());

        var ingresos = Db.dbListas().Item4
            .Where(t => t.idConcert == id)
            .Sum(t => t.price);

        var concierto = Db.dbListas().Item2.Find(c => c.idConcert == id);

        if (concierto == null)
        {
            Console.WriteLine("No existe un concierto con ese ID.");
        }
        else
        {
            Console.WriteLine($"Ingresos del concierto {concierto.city} ({concierto.date}): {ingresos}");
        }
        MenuConsults.menuConsults();
    }

    // Consultar cliente con más compras realizadas
    public static void clienteConMasCompras()
    {
        var tickets = Db.dbListas().Item4;
        if (tickets.Count == 0)
        {
            Console.WriteLine("No hay tiquetes registrados.");
            return;
        }

        var clienteId = tickets
            .GroupBy(t => t.idClient)
            .OrderByDescending(g => g.Count())
            .First().Key;

        var cliente = Db.dbListas().Item3.Find(c => c.idClient == clienteId);
        var persona = Db.dbListas().Item1.Find(p => p.idPerson == cliente.idPerson);

        Console.WriteLine($"Cliente con más compras: {persona.name} (ID Cliente: {cliente.idClient})");
        MenuConsults.menuConsults();
    }
}
