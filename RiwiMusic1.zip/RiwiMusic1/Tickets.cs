namespace RiwiMusic1.Models;

public class Tickets
{
    public static void mostrarTiquetes()
    {
        Console.WriteLine("----------Mostrar Tiquetes----------");
        if (Db.dbListas().Item4.Count == 0)
        {
            Console.WriteLine("No hay tiquetes registrados");
        }
        else
        {
            foreach (var t in Db.dbListas().Item4)
            {
                var cliente = Db.dbListas().Item3.Find(c => c.idClient == t.idClient);
                var persona = Db.dbListas().Item1.Find(p => p.idPerson == cliente.idPerson);
                var concierto = Db.dbListas().Item2.Find(c => c.idConcert == t.idConcert);

                Console.WriteLine($"ID Tiquete: {t.idTicket} -- Cliente: {persona.name} -- Concierto: {concierto.city} -- Fecha: {concierto.date} -- Precio: {t.price}");
            }
        }
        MenuTickets.menuTickets();
    }

    public static void registrarTiquete()
    {
        Console.WriteLine("----------Registrar Tiquete----------");
        
        Console.Write("ID Tiquete: ");
        int id = int.Parse(Console.ReadLine());

        Console.Write("ID Cliente: ");
        int idCliente = int.Parse(Console.ReadLine());

        Console.Write("ID Concierto: ");
        int idConcierto = int.Parse(Console.ReadLine());

        Console.Write("Precio: ");
        double precio = double.Parse(Console.ReadLine());

        var nuevoTiquete = new Ticket
        {
            idTicket = id,
            idClient = idCliente,
            idConcert = idConcierto,
            price = precio
        };

        Db.dbListas().Item4.Add(nuevoTiquete);
        Console.WriteLine("Tiquete Registrado con éxito");

        MenuTickets.menuTickets();
    }

    public static void editarTiquete()
    {
        Console.WriteLine("----------Editar Tiquete----------");
        foreach (var t in Db.dbListas().Item4)
        {
            Console.WriteLine($"ID Tiquete: {t.idTicket} -- ClienteID: {t.idClient} -- ConciertoID: {t.idConcert} -- Precio: {t.price}");
        }

        Console.Write("Ingrese el ID del tiquete que desea editar: ");
        int id = int.Parse(Console.ReadLine());

        var tiquete = Db.dbListas().Item4.Find(t => t.idTicket == id);
        if (tiquete != null)
        {
            Console.Write("Nuevo Precio: ");
            double nuevoPrecio = double.Parse(Console.ReadLine());
            tiquete.price = nuevoPrecio;

            Console.WriteLine("Tiquete Actualizado con éxito");
        }
        else
        {
            Console.WriteLine("No se encontró un tiquete con ese ID.");
        }
        MenuTickets.menuTickets();
    }

    public static void eliminarTiquete()
    {
        Console.WriteLine("----------Eliminar Tiquete----------");
        foreach (var t in Db.dbListas().Item4)
        {
            Console.WriteLine($"ID Tiquete: {t.idTicket} -- ClienteID: {t.idClient} -- ConciertoID: {t.idConcert} -- Precio: {t.price}");
        }

        Console.Write("Ingrese el ID del tiquete que desea eliminar: ");
        int id = int.Parse(Console.ReadLine());

        var tiquete = Db.dbListas().Item4.Find(t => t.idTicket == id);

        if (tiquete != null)
        {
            Db.dbListas().Item4.Remove(tiquete);
            Console.WriteLine("Tiquete eliminado con éxito.");
        }
        else
        {
            Console.WriteLine("No se encontró un tiquete con ese ID.");
        }
        MenuTickets.menuTickets();
    }
    
    public static void mostrarTiquetesPorCliente()
    {
        Console.Write("Ingrese el ID del cliente: ");
        int idCliente = int.Parse(Console.ReadLine());

        var cliente = Db.dbListas().Item3.Find(c => c.idClient == idCliente);
        var persona = Db.dbListas().Item1.Find(p => p.idPerson == cliente.idPerson);

        var ticketsCliente = Db.dbListas().Item4.Where(t => t.idClient == idCliente).ToList();

        Console.WriteLine($"Tiquetes de {persona.name}:");
        foreach (var t in ticketsCliente)
        {
            var concierto = Db.dbListas().Item2.Find(c => c.idConcert == t.idConcert);
            Console.WriteLine($"ID: {t.idTicket} -- Concierto: {concierto.city} ({concierto.date}) -- Precio: {t.price}");
        }
        MenuTickets.menuTickets();
    }

    
    public static void mostrarTotalGanado()
    {
        double total = Db.dbListas().Item4.Sum(t => t.price);
        Console.WriteLine($"Total ganado en ventas de tiquetes: {total}");
        
        MenuTickets.menuTickets();
    }
    
}
