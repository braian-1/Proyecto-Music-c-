namespace RiwiMusic1.Models;

public class MenuTickets
{
    public static void menuTickets()
    {
        Console.WriteLine("----------Menu de opciones----------");
        Console.WriteLine("1. Mostrar Tiquetes");
        Console.WriteLine("2. Registrar Tiquetes");
        Console.WriteLine("3. Editar Tiquetes");
        Console.WriteLine("4. Eliminar Tiquetes");
        Console.WriteLine("5. Mostrar Tiquetes por cliente");
        Console.WriteLine("6. Mostrar el total ganado");
        Console.WriteLine("7. Regresar al menu principal");

        Console.WriteLine("¿Que deseas hacer?");
        string opcion = Console.ReadLine();

        switch (opcion)
        {
            case "1":
                Tickets.mostrarTiquetes();
                break;
            case "2":
                Tickets.registrarTiquete();
                break;
            case "3":
                Tickets.editarTiquete();
                break;
            case "4":
                Tickets.eliminarTiquete();
                break;
            case "5":
                Tickets.mostrarTiquetesPorCliente();
                break;
            case "6":
                Tickets.mostrarTotalGanado();
                break;
            case "7":
                Menu.menu();
                break;
            default:
                Console.WriteLine("Ingrese una opcion valida");
                menuTickets();
                return;

        }
    }
}