namespace RiwiMusic1.Models;

public class Ticket
{
    public int idTicket { get; set; }
    public int idConcert { get; set; }
    public int idClient { get; set; }
    public double price { get; set; }
}