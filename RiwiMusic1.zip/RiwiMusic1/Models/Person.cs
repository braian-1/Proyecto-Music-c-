namespace RiwiMusic1.Models;

public class Person
{
    public int idPerson { get; set; }
    public string name {get; set;}
    public string email {get; set;}
    public int age {get; set;}
    public string document { get; set; }
    public string phone { get; set; }
    public string genero { get; set; } 
}