namespace RiwiMusic1.Models;

public class Concert
{
    public int idConcert { get; set; }
    public string date { get; set; }
    public string city { get; set; }
}


