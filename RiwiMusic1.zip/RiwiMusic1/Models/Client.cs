namespace RiwiMusic1.Models;

public class Client
{
    public int idClient { get; set; }
    public int idPerson { get; set; }
}