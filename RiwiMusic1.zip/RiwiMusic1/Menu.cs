namespace RiwiMusic1.Models;

public class Menu
{
    public static void menu()
    {
        Console.WriteLine("----------Menu de opciones----------");
        Console.WriteLine("1. Menu De Conciertos");
        Console.WriteLine("2. Menu De Personas");
        Console.WriteLine("3. Menu De Tickets");
        Console.WriteLine("4. Menu De Consultas");
        Console.WriteLine("5. Salir");
        
        Console.WriteLine("¿Que deseas hacer?");
        string opcion = Console.ReadLine();

        switch (opcion)
        {
            case "1":
                MenuConcerts.menuConcerts();
                break;
            case "2" :
                MenuPersons.menuPersons();
                break;
            case "3":
                MenuTickets.menuTickets();
                break;
            case "4":
                MenuConsults.menuConsults();
                break;
            case "5":
                Console.WriteLine("Gracias Por Visitarnos");
                break;
            default:
                Console.WriteLine("Ingrese una opcion valida");
                menu();
                return;
                
        }
    }
}