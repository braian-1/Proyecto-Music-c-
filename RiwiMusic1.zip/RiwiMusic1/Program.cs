﻿using System.Reflection.Metadata;

namespace RiwiMusic1.Models;

public class Program
{
    public static void Main(string[] args)
    {
        Menu.menu();
    }
}