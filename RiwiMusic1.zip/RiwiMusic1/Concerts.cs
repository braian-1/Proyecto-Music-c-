namespace RiwiMusic1.Models;

public class Concerts
{
    public static void mostrarConcierto()
    {
        Console.WriteLine("----------Mostrar Concierto----------");
        if (Db.dbListas().Item2.Count == 0)
        {
            Console.WriteLine("No hay conciertos registrados");
        }
        else
        {
            foreach (var d in Db.dbListas().Item2)
            {
                Console.WriteLine($"ID: {d.idConcert} -- {d.city} -- {d.date}");
            }
        }
        MenuConcerts.menuConcerts();
    }
    
    public static void registrarConcierto()
    {
        Console.WriteLine("----------Registro de Concierto----------");
        
        Console.Write("ID: ");
        int id = int.Parse(Console.ReadLine());
        
        Console.Write("Fecha: ");
        string fecha = Console.ReadLine();
        
        Console.Write("Ciudad: ");
        string ciudad = Console.ReadLine();

        var nuevoConcierto = new Concert
        {
            idConcert = id,
            date = fecha,
            city = ciudad
        };
        
        Db.dbListas().Item2.Add(nuevoConcierto);
        Console.WriteLine("Concierto Registrado");
        
        MenuConcerts.menuConcerts();
    }
    
    public static void editarConcierto()
    {
        Console.WriteLine("----------Editar Concierto----------");
        foreach (var c in Db.dbListas().Item2)
        {
            Console.WriteLine($"ID: {c.idConcert} -- {c.city} -- {c.date}");
        }
        Console.WriteLine("Ingrese el ID del concierto que desea editar");
        int id = int.Parse(Console.ReadLine());
        
        var concierto = Db.dbListas().Item2.Find(c => c.idConcert == id);
        if (concierto != null)
        {
            Console.Write("Nueva Fecha: ");
            string fecha = Console.ReadLine();
            Console.Write("Nueva Ciudad: ");
            string ciudad = Console.ReadLine();
            
            concierto.date = fecha;
            concierto.city = ciudad;
            
            Console.WriteLine("Concierto Actualizado con exito");
        }
        else
        {
            Console.WriteLine("No se encontro un concierto con ese ID.");
        }
        MenuConcerts.menuConcerts();
    }

    public static void eliminarConcierto()
    {
        Console.WriteLine("----------Eliminar Concierto----------");
        foreach (var c in Db.dbListas().Item2)
        {
            Console.WriteLine($"ID: {c.idConcert} -- {c.city} -- {c.date}");
        }

        Console.Write("Ingrese el ID del concierto que desea eliminar: ");
        int id = int.Parse(Console.ReadLine());
        
        var concierto = Db.dbListas().Item2.Find(c => c.idConcert == id);

        if (concierto != null)
        {
            Db.dbListas().Item2.Remove(concierto);
            Console.WriteLine("Concierto eliminado con éxito.");
        }
        else
        {
            Console.WriteLine("No se encontró un concierto con ese ID.");
        }
        MenuConcerts.menuConcerts();
    }
    
    public static void mostrarConciertoPorCiudad()
    {
        Console.WriteLine("----------Mostrar Conciertos por Ciudad----------");
        Console.Write("Ingrese la ciudad: ");
        string ciudadBuscada = Console.ReadLine();
        
        //Consulta LAMDBA
        var conciertosCiudad = Db.dbListas().Item2
            .Where(c => c.city.Equals(ciudadBuscada))
            .ToList();//El ToList sirve para cambiar el resultado a una lista

        if (conciertosCiudad.Count == 0)
        {
            Console.WriteLine($"No hay conciertos registrados en la ciudad: {ciudadBuscada}");
        }
        else
        {
            foreach (var c in conciertosCiudad)
            {
                Console.WriteLine($"ID: {c.idConcert} -- {c.city} -- {c.date}");
            }
        }
        MenuConcerts.menuConcerts();
    }
}
