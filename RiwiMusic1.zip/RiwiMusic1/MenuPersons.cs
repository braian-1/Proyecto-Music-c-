namespace RiwiMusic1.Models;

public class MenuPersons
{
    public static void menuPersons()
    {
        Console.WriteLine("----------Menu De Opciones De Personas----------"); 
        Console.WriteLine("1. Mostrar Personas");
        Console.WriteLine("2. Registrar Personas");
        Console.WriteLine("3. Editar Personas");
        Console.WriteLine("4. Eliminar Personas"); 
        Console.WriteLine("5. Regresar A Menu Principal");
        
        Console.WriteLine("¿Que deseas hacer?");
        string opcion = Console.ReadLine();

        switch (opcion)
        {
            case "1":
                Persons.mostrarPersonas();
                break;
            case "2":
                Persons.registrarPersonas();
                break;
            case "3":
                Persons.editarPersonas();
                break;
            case "4":
                Persons.eliminarPersonas();
                break;
            case "5":
                Menu.menu();
                break;
            default:
                Console.WriteLine("Ingrese una opcion valida");
                menuPersons();
                return;
        }
    }
}