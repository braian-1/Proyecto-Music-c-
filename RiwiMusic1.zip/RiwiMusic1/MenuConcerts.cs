namespace RiwiMusic1.Models;

public class MenuConcerts
{
    public static void menuConcerts()
    {
        Console.WriteLine("----------Menu De Opciones De Conciertos----------"); 
        Console.WriteLine("1. Mostrar Conciertos");
        Console.WriteLine("2. Registrar Conciertos");
        Console.WriteLine("3. Editar Conciertos");
        Console.WriteLine("4. Eliminar Conciertos");
        Console.WriteLine("5. Mostrar Conciertos Por Ciudad");
        Console.WriteLine("6. Regresar A Menu Principal");
        
        Console.WriteLine("¿Que deseas hacer?");
        string opcion = Console.ReadLine();

        switch (opcion)
        {
            case "1":
                Concerts.mostrarConcierto();
                break;
            case "2":
                Concerts.registrarConcierto();
                break;
            case "3":
                Concerts.editarConcierto();
                break;
            case "4":
                Concerts.eliminarConcierto();
                break;
            case "5":
                Concerts.mostrarConciertoPorCiudad();
                break;
            case "6":
                Menu.menu();
                break;
            default:
                Console.WriteLine("Ingrese una opcion valida");
                menuConcerts();
                return;
        }
    }
}