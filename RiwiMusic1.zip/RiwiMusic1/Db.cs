namespace RiwiMusic1.Models;

public class Db
{
    private static List<Person> persons = new List<Person>
    {
        new Person { idPerson = 1, name = "Andres", email = "andres@gmail.com", age = 20, document = "82127121", phone = "3219237283", genero = "Masculino" },
        new Person { idPerson = 2, name = "Pepito", email = "pepito@gmail.com", age = 30, document = "203698214", phone = "3207832211", genero = "Masculino" },
        new Person { idPerson = 3, name = "Ana", email = "ana@gmail.com", age = 24, document = "64205266", phone = "317852112", genero = "Femenino" },
        new Person { idPerson = 4, name = "Pepita", email = "pepita@gmail.com", age = 27, document = "784695650", phone = "3138796541", genero = "Femenino" },
        new Person { idPerson = 5, name = "David", email = "david@gmail.com", age = 18, document = "999875331", phone = "3145469210", genero = "Masculino" },
        new Person { idPerson = 6, name = "Carlos", email = "carlos@gmail.com", age = 19, document = "48989879", phone = "98745222", genero = "Masculino" },
        new Person { idPerson = 7, name = "Sergio", email = "sergio@gmail.com", age = 23, document = "55468411", phone = "3203287774", genero = "Masculino" },
        new Person { idPerson = 8, name = "Stiven", email = "stiven@gmail.com", age = 21, document = "989846", phone = "9878751651", genero = "Masculino" },
        new Person { idPerson = 9, name = "Luis", email = "luis@gmail.com", age = 29, document = "03258751", phone = "3458702339", genero = "Masculino" },
        new Person { idPerson = 10, name = "Eduar", email = "eduar@gmail.com", age = 28, document = "20169741", phone = "387556955", genero = "Masculino" }
    };

    private static List<Concert> concerts = new List<Concert>
    {
        new Concert { idConcert = 1, date = "12 de junio 2025", city = "Medellin" },
        new Concert { idConcert = 2, date = "20 de marzo 2025", city = "Miami" },
        new Concert { idConcert = 3, date = "24 de diciembre 2026", city = "New York" },
        new Concert { idConcert = 4, date = "01 de enero 2026", city = "Bogota" },
        new Concert { idConcert = 5, date = "03 de agosto 2025", city = "Toronto" },
        new Concert { idConcert = 6, date = "01 de febrero 2025", city = "Medellin" },
        new Concert { idConcert = 7, date = "10 de junio 2025", city = "Miami" },
        new Concert { idConcert = 8, date = "02 de mayo 2026", city = "New York" },
        new Concert { idConcert = 9, date = "11 de noviembre 2025", city = "Cali" },
        new Concert { idConcert = 10, date = "24 de octubre 2025", city = "Toronto" }
    };

    private static List<Ticket> tickets = new List<Ticket>
    {
        new Ticket { idTicket = 1, idConcert = 1, idClient = 2, price = 10000 },
        new Ticket { idTicket = 2, idConcert = 5, idClient = 4, price = 20000 },
        new Ticket { idTicket = 3, idConcert = 3, idClient = 3, price = 30000 },
        new Ticket { idTicket = 4, idConcert = 4, idClient = 5, price = 40000 },
        new Ticket { idTicket = 5, idConcert = 2, idClient = 1, price = 50000 },
        new Ticket { idTicket = 6, idConcert = 8, idClient = 8, price = 60000 },
        new Ticket { idTicket = 7, idConcert = 10, idClient = 10, price = 70000 },
        new Ticket { idTicket = 8, idConcert = 9, idClient = 7, price = 80000 },
        new Ticket { idTicket = 9, idConcert = 6, idClient = 9, price = 90000 },
        new Ticket { idTicket = 10, idConcert = 7, idClient = 6, price = 100000 },
    };

    private static List<Client> clients = new List<Client>
    {
        new Client { idClient = 1, idPerson = 1 },
        new Client { idClient = 2, idPerson = 5 },
        new Client { idClient = 3, idPerson = 4 },
        new Client { idClient = 4, idPerson = 2 },
        new Client { idClient = 5, idPerson = 3 },
        new Client { idClient = 6, idPerson = 7 },
        new Client { idClient = 7, idPerson = 10 },
        new Client { idClient = 8, idPerson = 9 },
        new Client { idClient = 9, idPerson = 8 },
        new Client { idClient = 10, idPerson = 6 },
    };
    public static (List<Person>, List<Concert>, List<Client>, List<Ticket>) dbListas()
    {
        return (persons, concerts, clients, tickets);
    }
}
