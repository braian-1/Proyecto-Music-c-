namespace RiwiMusic1.Models;

public class MenuConsults
{
    public static void menuConsults()
    {
        Console.WriteLine("----------Menu de opciones----------");
        Console.WriteLine("1. Conciertos por ciudad");
        Console.WriteLine("2. Concierto por rango de fechas");
        Console.WriteLine("3. Concierto con mas tiquetes vendidos");
        Console.WriteLine("4. ingresos por conciertos");
        Console.WriteLine("5. Cliente con mas compras");
        Console.WriteLine("6. regresar al menu principal");

        Console.WriteLine("¿Que deseas hacer?");
        string opcion = Console.ReadLine();

        switch (opcion)
        {
            case "1":
                Consultas.conciertosPorCiudad();
                break;
            case "2":
                Consultas.conciertosPorRangoFechas();
                break;
            case "3":
                Consultas.conciertoMasTiquetesVendidos();
                break;
            case "4":
                Consultas.ingresosPorConcierto();
                break;
            case "5":
                Consultas.clienteConMasCompras();
                break;
            case "6":
                Menu.menu();
                break;
            default:
                Console.WriteLine("Ingrese una opcion valida");
                menuConsults();
                return;

        }
    }
}