namespace RiwiMusic1.Models;

public class Persons
{
    
    public static void mostrarPersonas()
    {
        var resultado = Db.dbListas();
        var person1 = resultado.Item1;

        foreach (var p in person1)
        {
            Console.WriteLine($"Nombre: {p.name}---Edad: {p.age}---Email: {p.email}---Telefono: {p.phone}---Documento: {p.document}---Genero: {p.genero}");
        }
        MenuPersons.menuPersons();
    } 
    public static void registrarPersonas()
    {
        Console.WriteLine("----------Registrar Personas----------");
        Console.Write("ID: ");
        int id = int.Parse(Console.ReadLine());
        Console.Write("Nombre: ");
        string nombre = Console.ReadLine();
        Console.Write("Correo: ");
        string correo = Console.ReadLine();
        Console.Write("Edad: ");
        int edad = int.Parse(Console.ReadLine());
        Console.Write("Documento: ");
        string documento = Console.ReadLine();
        Console.Write("Telefono: ");
        string telefono = Console.ReadLine();
        Console.Write("Genero: ");
        string genero = Console.ReadLine();

        var nuevoCliente = new Person
        {
            idPerson = id,
            name = nombre,
            email = correo,
            age = edad,
            document = documento,
            phone = telefono,
            genero = genero
        };
        Db.dbListas().Item1.Add(nuevoCliente);
        Console.WriteLine("Persona Registrada");

        MenuPersons.menuPersons();
    } 
    
    public static void editarPersonas()
    {
        Console.WriteLine("----------Editar Personas----------");
        foreach (var p in Db.dbListas().Item1)
        {
            Console.WriteLine($"Id: {p.idPerson}---Nombre: {p.name}---Edad: {p.age}---Email: {p.email}---Telefono: {p.phone}---Documento: {p.document}---Genero: {p.genero}");
        }
        Console.WriteLine("Ingrese el ID de la persona que desea editar");
        int id = int.Parse(Console.ReadLine());
        
        var persona = Db.dbListas().Item1.Find(c => c.idPerson == id);
        if (persona != null)
        {
            Console.Write("Nuevo Nombre: ");
            string nombre = Console.ReadLine();
            Console.Write("Correo: ");
            string correo = Console.ReadLine();
            Console.Write("Edad: ");
            int edad = int.Parse(Console.ReadLine());
            Console.Write("Documento: ");
            string document = Console.ReadLine();
            Console.Write("Telefono: ");
            string telefono = Console.ReadLine();
            Console.Write("Genero: ");
            string genero = Console.ReadLine();

            persona.name = nombre;
            persona.email = correo;
            persona.age = edad;
            persona.document = document;
            persona.phone = telefono;
            persona.genero = genero;
            
            Console.WriteLine("Persona Actualizada con exito");
        }
        else
        {
            Console.WriteLine("No se encontro la persona con ese ID.");
        }

        MenuPersons.menuPersons();
    }

    public static void eliminarPersonas()
    {
        Console.WriteLine("----------Eliminar Personas----------");
        foreach (var p in Db.dbListas().Item1)
        {
            Console.WriteLine($"Id: {p.idPerson}---Nombre: {p.name}---Edad: {p.age}---Email: {p.email}---Telefono: {p.phone}---Documento: {p.document}---Genero: {p.genero}");
        }
        Console.Write("Ingrese el ID de la persona que desea eliminar: ");
        int id = int.Parse(Console.ReadLine());
        
        var persona = Db.dbListas().Item1.Find(c => c.idPerson == id);

        if (persona != null)
        {
            Db.dbListas().Item1.Remove(persona);
            Console.WriteLine("Persona Eliminada Con Exito");
        }
        else
        {
            Console.WriteLine("No se encontro la persona con ese ID.");
        }
        MenuPersons.menuPersons();
    }
}